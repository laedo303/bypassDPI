Экспериментальные настройки веб-браузера:

opera://flags
chrome://flags
edge://flags

перевести в положение "Enabled" следущие настройки:
Experimental QUIC protocol
TLS 1.3 hybridized Kyber support

Если папка "zapret_DPI_bypass_software" не удаляется, то запустите командную строку от
имени администратора и наберите там следующую команду (без кавычек):
sc stop WinDivert